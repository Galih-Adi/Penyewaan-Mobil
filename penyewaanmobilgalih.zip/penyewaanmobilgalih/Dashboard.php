<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <!-- Font Awesome CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style>
    /* Custom CSS */
    body{
      background-image: url('L1.jpg');
      background-size: cover;
      background-repeat: no-repeat;
    }
    .sidebar {
      height: 100vh;
      background-image: url('Red.jpg');
      background-size: cover;
      background-repeat: no-repeat;
      z-index: 1;
    }
    .sidebar-logo {
      padding: 20px;
      color: #fff;
    }
    .sidebar-menu {
      margin-top: 20px;
    }
    .sidebar-menu .btn {
      width: 100%;
      margin-bottom: 10px;
    }
    .sidebar-footer {
      position: absolute;
      bottom: 20px;
      width: 100%;
    }
    .user-profile {
      text-align: right;
      padding: 20px;
      display: flex;
      align-items: center;
      justify-content: flex-end;
      position: fixed;
      top: 0;
      right: 0;
      z-index: 999;
    }
    .user-profile img {
      margin-right: 10px;
    }
    .user-profile .profile-btn {
      background: none;
      border: none;
      color: blanchedalmond;
      cursor: pointer;
    }
    .welcome-message {
      margin-right: 100px;
      color: blanchedalmond;
    }
    .top-bar {
      background-image: url('Red.jpg');
      background-size: cover;
      background-repeat: no-repeat;
      height: 100px;
      position: fixed;
      top: 0;
      left: 0px; /* Lebar sidebar */
      right: 0;
      z-index: 0;
    }
    .bottom-bar {
      background-image: url('Red.jpg');
      background-size: cover;
      background-repeat: no-repeat;
      height: 20px; /* tinggi bottom bar */
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      z-index: 0; /* z-index 0 */
    }
    .marquee-link {
      color: white;
    }
    .marquee-link:hover {
      color: yellow;
    }
    .sidebar-toggle-btn {
      background: none;
      border: none;
      color: #fff;
      cursor: pointer;
      padding: 10px;
      font-size: 24px;
      position: absolute;
      top: 20px;
      right: 20px;
      z-index: 999;
    }
  </style>
</head>
<body>

  <div class="container-fluid">
    <div class="row">
      <!-- Sidebar -->
      <div class="col-md-3 position-relative sidebar">
        <button class="sidebar-logo btn btn-link">
          <img src="M3.png" alt="Logo" width="50" height="50">
          <a style="color: #fff;" href="Dashboard.php"> Ma'uRent</a>
        </button>
        <div class="sidebar-menu">
          <button class="btn btn-primary"><i class="fas fa-car"></i><a style="color: #fff;" href="Kendaraan.php"> Kendaraan</a></button>
          <button class="btn btn-primary"><i class="fas fa-users"></i><a style="color: #fff;" href="Customer.php"> Customer</a></button>
          <button class="btn btn-primary"><i class="fas fa-receipt"></i><a style="color: #fff;" href="Transaksi.php"> Transaksi</a></button>
        </div>
        <div class="sidebar-footer">
          <button class="btn btn-danger"><i class="fas fa-sign-out-alt"></i><a style="color: #fff;" href="Index.php"> Logout</a></button>
        </div>
      </div>
      <!-- Top Bar -->
      <div class="top-bar"></div>
      <div class="bottom-bar">
        <marquee direction="right" scrollamount="10">
          <a href="https://youtu.be/dQw4w9WgXcQ?si=mLV9R6ByokTWbavt">
            <p style="font: size 50px;">https://Ma'uRent.co.id</p>
          </a>
        </marquee>
      </div>
  </div>
      <!-- Content -->
      <div class="col-md-9">
        <!-- Top Right User Profile -->
        <div class="user-profile">
          <h1 class="welcome-message">Welcome to Ma'uRent</h1>
          <button class="profile-btn">
            <img src="Poto Profil.jpg" alt="Profile Picture" width="50" height="50">
            G B Adi
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
