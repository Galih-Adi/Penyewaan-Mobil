<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kendaraan</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <!-- Font Awesome CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style>
    /* Custom CSS */
    body{
      background-image: url('L1.jpg');
      background-size: cover;
      background-repeat: no-repeat;
    }
    .sidebar {
      height: 100vh;
      background-image: url('Red.jpg');
      background-size: cover;
      background-repeat: no-repeat;
      z-index: 1;
    }
    .sidebar-logo {
      padding: 20px;
      color: #fff;
    }
    .sidebar-menu {
      margin-top: 20px;
    }
    .sidebar-menu .btn {
      width: 100%;
      margin-bottom: 10px;
    }
    .sidebar-footer {
      position: absolute;
      bottom: 20px;
      width: 100%;
    }
    .user-profile {
      text-align: right;
      padding: 20px;
      display: flex;
      align-items: center;
      justify-content: flex-end;
      position: fixed;
      top: 0;
      right: 0;
      z-index: 999;
    }
    .user-profile img {
      margin-right: 10px;
    }
    .user-profile .profile-btn {
      background: none;
      border: none;
      color: blanchedalmond;
      cursor: pointer;
    }
    .welcome-message {
      margin-right: 100px;
      color: blanchedalmond;
    }
    .top-bar {
      background-image: url('Red.jpg');
      background-size: cover;
      background-repeat: no-repeat;
      height: 100px;
      position: fixed;
      top: 0;
      left: 0px; /* Lebar sidebar */
      right: 0;
      z-index: 0;
    }
    .table thead th{
      background-color: aqua;
      border: 2px solid #000;
    }
    .table tbody tr{
      background-color: #fff;
      border: 2px solid #000;
    }
    tr,th{
      color: #000;
      background-color: antiquewhite;
      border: 2px solid #000;
    }
    td{
      background-color: #14e725
    }
    .bottom-bar {
      background-image: url('Red.jpg');
      background-size: cover;
      background-repeat: no-repeat;
      height: 20px; /* tinggi bottom bar */
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      z-index: 0; /* z-index 0 */
    }
    .sidebar-toggle-btn {
      background: none;
      border: none;
      color: #fff;
      cursor: pointer;
      padding: 10px;
      font-size: 24px;
      position: absolute;
      top: 20px;
      right: 20px;
      z-index: 999;
    }
    .pagination {
            margin-top: 20px;
            text-align: center;
        }

        .pagination a {
            display: inline-block;
            padding: 5px 10px;
            background-color: #333;
            color: #fff;
            text-decoration: none;
            border-radius: 3px;
            font-size: 14px;
            margin-left: 200px;
        }

        .pagination a.current {
            background-color: #555;
        }
  </style>
</head>
<body>

  <div class="container-fluid">
    <div class="row">
      <!-- Sidebar -->
      <div class="col-md-3 position-relative sidebar">
        <button class="sidebar-logo btn btn-link">
          <img src="M3.png" alt="Logo" width="50" height="50">
          <a style="color: #fff;" href="Dashboard.php"> Ma'uRent</a>
        </button>
        <div class="sidebar-menu">
          <button class="btn btn-primary"><i class="fas fa-car"></i><a style="color: #fff;" href="Kendaraan.php"> Kendaraan</a></button>
          <button class="btn btn-primary"><i class="fas fa-users"></i><a style="color: #fff;" href="Customer.php"> Customer</a></button>
          <button class="btn btn-primary"><i class="fas fa-receipt"></i><a style="color: #fff;" href="Transaksi.php"> Transaksi</a></button>
        </div>
        <div class="sidebar-footer">
          <button class="btn btn-danger"><i class="fas fa-sign-out-alt"></i><a style="color: #fff;" href="index.php"> Logout</a></button>
        </div>
      </div>
      <!-- Top Bar -->
      <div class="top-bar"></div>
      <!-- Content -->
      <div class="col-md-9">
        <!-- Top Right User Profile -->
        <div class="user-profile">
          <h1 class="welcome-message">Table Kendaraan</h1>
          <button class="profile-btn">
            <img src="Poto Profil.jpg" alt="Profile Picture" width="50" height="50">
            G B Adi
          </button>
        </div>
        <!-- Main Content Goes Here -->
        <div class="content" style="margin-top: 20px;">
          <!-- Tombol Tambah -->
          <div class="centered mb-3" style="margin-top:150px;">
            <button class="btn btn-primary"></i><a style="color: #fff;" href="KendaraanTambah1.php"> Tambah</a></button>
          </div>
          <!-- Tombol Tambah dan Search -->
                    <div class="input-group mb-4" style="padding: 20px; width: 500px; margin-left: 100px; margin-top: -75px ;">
                      <input type="text" class="form-control" placeholder="Cari..." aria-label="Cari..." aria-describedby="basic-addon2">
                       <div class="input-group-append">
                     <button class="btn btn-outline-secondary" type="button"><a style="color: #fff;">Cari</button>
                    </div>
                  </div>
          <!-- Tabel Nomor Polisi -->
          <table border="1" align="center" width="100%">
    <tr bgcolor="green">
        <th>Nomor Polisi</th>
        <th>Armada</th>
        <th>Sewa Kendaraan</th>
        <th>Supir</th>
        <th>BBM</th>
        <th>Total</th>
        <th>Aksi</th>

    </tr>
    <tr>
        <?php
            include 'koneksi.php';
            $limit = 10; // Jumlah baris per halaman
            $page = isset($_GET['page']) ? $_GET['page'] : 1;
            $start = ($page - 1) * $limit;
        
            $query = mysqli_query($conn, "SELECT * FROM kendaraan LIMIT $start, $limit");
            while ($data=mysqli_fetch_array($query)){
                ?>
                <tr>
                <td><?php echo $data['nomorpolisi'] ;?></td>
                <td><?php echo $data['armada'] ;?></td>
                <td><?php echo $data['sewakendaraan'] ;?></td>
                <td><?php echo $data['supir'] ;?></td>
                <td><?php echo $data['bbm'] ;?></td>
                <td><?php echo $data['total'] ;?></td>
                <td>
				<a class="edit" href="KendaraanUbah1.php?nomorpolisi=<?php echo $data['nomorpolisi'];?>" >Edit</a> |
				<a class="hapus" href="KendaraanHapus1.php?nomorpolisi=<?php echo $data['nomorpolisi']; ?>" onclick="return confirm('yakin hapus?')">Hapus</a>				
			</td>
            </tr>
            </tr>
            <?php } ?>

</table>

        <div class="pagination">
            <?php
            $query_total = mysqli_query($conn, "SELECT COUNT(*) as total FROM kendaraan");
            $data_total = mysqli_fetch_assoc($query_total);
            $total_pages = ceil($data_total['total'] / $limit);

            if ($page > 1) {
                echo '<a href="?page=' . ($page - 1) . '">Back</a>';
            }

            for ($i = 1; $i <= $total_pages; $i++) {
                if ($i == $page) {
                    echo '<a href="?page=' . $i . '" class="current">' . $i . '</a>';
                } else {
                    echo '<a href="?page=' . $i . '">' . $i . '</a>';
                }
            }

            if ($page < $total_pages) {
                echo '<a href="?page=' . ($page + 1) . '">Next</a>';
            }
            ?>
</div>
<!-- Bottom Bar -->
<div class="bottom-bar">
  <marquee direction="right" scrollamount="10">
    <a href="https://youtu.be/dQw4w9WgXcQ?si=mLV9R6ByokTWbavt">
      <p style="font: size 50px;">https://Ma'uRent.co.id</p>
    </a>
  </marquee>
</div>
</div>
  <!-- Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
