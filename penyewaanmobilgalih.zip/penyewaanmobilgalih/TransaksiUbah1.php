<?php
            include 'koneksi.php';
            $query = mysqli_query($conn, "Select*from transaksi where nomor_transaksi = '$_GET[nomor_transaksi]'");
            $data = mysqli_fetch_array($query);
            
                ?>
  
<html>
<title>Edit Transaksi</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f1f1f1;
        margin: 0;
        padding: 20px;
    }

    h3 {
        color: #333;
        font-size: 24px;
        text-align: center;
        margin-bottom: 20px;
    }

    form {
        background-color: #fff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
    }

    table {
        width: 100%;
    }

    h4 {
        text-align: center;
        color: #666;
        font-size: 18px;
        margin-bottom: 10px;
    }

    tr {
        line-height: 2;
    }

    td:first-child {
        text-align: right;
        padding-right: 10px;
        color: #666;
        font-weight: bold;
    }

    input[type="text"] {
        width: 100%;
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 3px;
        font-size: 14px;
    }

    input[type="submit"] {
        padding: 8px 15px;
        background-color: #4CAF50;
        color: #fff;
        border: none;
        border-radius: 3px;
        cursor: pointer;
        font-size: 14px;
    }

    input[type="submit"]:hover {
        background-color: #45a049;
    }

    .kembali {
        
        padding: 10px 10px;
        background-color: #333;
        color: #fff;
        text-decoration: none;
        border-radius: 3px;
        font-size: 14px;
    }

    .kembali:hover {
        background-color: #555;
    }
</style>
<h3>MA'URENT</h3>
<form action="" method="post">
<table>
    <h4>FORM UBAH TRANSAKSI</h4>
    <tr>
        <td> Nomor Transaksi </td>
        <td> <input type="text" name="nomor_transaksi" value="<?php echo $data['nomor_transaksi'];?>" readonly> </td>
    </tr>
    <tr><td> 
        Id Customer
        <td><select name="idcustomer" style="width:170px;">
        <?php
        include 'koneksi.php';
        $ambilcustomer=mysqli_query($conn, "SELECT * FROM customer");
        while ($customer = mysqli_fetch_array($ambilcustomer)) {
            $selected = ($data['idcustomer'] == $customer['idcustomer']) ? 'selected' : '';
            echo "<option value='$customer[idcustomer]' $selected>$customer[idcustomer]</option>";
        }
        ?></td>
        </select>
    </td></tr>
    <tr><td> 
        Nomor Polisi
        <td><select name="nomorpolisi" style="width:170px;">
        <?php
        include 'koneksi.php';
        $ambilnopol=mysqli_query($conn, "SELECT * FROM kendaraan");
        while ($nopol = mysqli_fetch_array($ambilnopol)) {
            $selected = ($data['nomorpolisi'] == $nopol['nomorpolisi']) ? 'selected' : '';
            echo "<option value='$nopol[nomorpolisi]' $selected>$nopol[nomorpolisi]</option>";
        }
        ?></td>
        </select>
        </td></tr>
    <tr>
        <td> Biaya </td>
        <td> <input type="text" name="biaya" value="<?php echo $data['biaya'];?>"> </td>
    </tr>
    <tr>
        <td> Tujuan </td>
        <td> <input type="text" name="tujuan" value="<?php echo $data['tujuan'];?>"> </td>
    </tr>
    <tr>
        <td> Kota Berangkat
        <td> <input type="text" name="kotaberangkat" value="<?php echo $data['kotaberangkat'];?>"> </td>
    </tr>
    <tr>
        <td> Tanggal Berangkat
        <td> <input type="date" name="tanggalberangkat" value="<?php echo $data['tanggalberangkat'];?>"> </td>
    </tr>
    <tr>
        <td> Kota Kembali
        <td> <input type="text" name="kotakembali" value="<?php echo $data['kotakembali'];?>"> </td>
    </tr>
    <tr>
        <td> Tanggal Kembali
        <td> <input type="date" name="tanggalkembali" value="<?php echo $data['tanggalkembali'];?>"> </td>
    </tr>
    <tr>
        <td> Keterangan
        <td> <input type="text" name="keterangan" value="<?php echo $data['keterangan'];?>"> </td>
    </tr>
    <tr>
        <td> Lain-lain
        <td> <input type="text" name="lainlain" value="<?php echo $data['lainlain'];?>"> </td>
    </tr>
    <tr>
        <td> Petugas
        <td> <input type="text" name="petugas" value="<?php echo $data['petugas'];?>"> </td>
    </tr>
    <tr>
        <td></td>
        <td><a class="kembali" href="Transaksi.php">kembali</a>|<input type="submit" name="proses" value="Ubah Transaksi"> </td>
    </tr>
    </table>
</form>

</html>

<?php

if (isset($_POST['proses'])){
    include 'koneksi.php';

    $nomor_transaksi = $_POST['nomor_transaksi'];
    $idcustomer = $_POST['idcustomer'];
    $nomorpolisi = $_POST['nomorpolisi'];
    $biaya = $_POST['biaya'];
    $tujuan = $_POST['tujuan'];
    $kotaberangkat = $_POST['kotaberangkat'];
    $tanggalberangkat = $_POST['tanggalberangkat'];
    $kotakembali = $_POST['kotakembali'];
    $tanggalkembali = $_POST['tanggalkembali'];
    $keterangan = $_POST['keterangan'];
    $lainlain = $_POST['lainlain'];
    $petugas = $_POST['petugas'];
    
    
    mysqli_query($conn, "update transaksi set idcustomer='$idcustomer',nomorpolisi='$nomorpolisi',biaya='$biaya',tujuan = '$tujuan', kotaberangkat = '$kotaberangkat', tanggalberangkat = '$tanggalberangkat', kotakembali = '$kotakembali', tanggalkembali = '$tanggalkembali', keterangan = '$keterangan', lainlain = '$lainlain', petugas = '$petugas'  where nomor_transaksi='$nomor_transaksi'");
                            
    header("location:Transaksi.php");
}