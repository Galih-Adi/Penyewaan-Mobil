<html>
<title>Tambah Transaksi</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
    }
    
    h3 {
        color: #333;
        text-align: center;
        margin-top: 20px;
    }
    
    form {
        margin: 20px auto;
        width: 80%;
        background-color: #fff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
    
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    
    table td {
        padding: 10px;
        border: 1px solid #ccc;
    }
    
    table th {
        padding: 10px;
        background-color: #333;
        color: #fff;
        border: 1px solid #ccc;
    }
    
    table tr:nth-child(even) {
        background-color: #f2f2f2;
    }
    
    input[type="text"] {
        padding: 5px;
        width: 100%;
        box-sizing: border-box;
    }
    
    input[type="submit"] {
        padding: 8px 20px;
        background-color: #333;
        color: #fff;
        border: none;
        cursor: pointer;
    }
    
    input[type="submit"]:hover {
        background-color: #555;
    }
    
    .edit,
    .hapus,
    .kembali {
        padding: 7.5px 10px;
        background-color: #333;
        color: #fff;
        text-decoration: none;
        border-radius: 3px;
    }
    
    .edit:hover,
    .hapus:hover,
    .kembali:hover {
        background-color: #555;
    }
    
    .edit {
        margin-right: 5px;
    }
    
    .kembali {
        margin-top: 1px;
    }
    
    .kembali:hover {
        background-color: #f2f2f2;
        color: #333;
    }
</style>
<h3> MA'URENT </h3>

<form action="" method="post">
<table>
    <h4>FORM TRANSAKSI</h4>
    <tr>
        <td> Nomor Transaksi </td>
        <td> <input type="text" name="nomor_transaksi"> </td>
    </tr>
    <tr><td> 
        Id Customer
        <td><select name="idcustomer" style="width:170px;">
        <option value="">--Pilih--</option>
        <?php
        include 'koneksi.php';
        $query=mysqli_query($conn, "SELECT * FROM customer");
        while ($data = mysqli_fetch_array($query)) {
        ?>
          
            <option value="<?php echo $data['idcustomer'];?>" >
            <?php echo $data['idcustomer'];?></option>
        <?php
        }
        ?></td>
        </select>
        </td></tr>
    <tr><td> 
        Nomor Polisi
        <td><select name="nomorpolisi" style="width:170px;">
        <option value="">--Pilih--</option>
        <?php
        include 'koneksi.php';
        $query=mysqli_query($conn, "SELECT * FROM kendaraan");
        while ($data = mysqli_fetch_array($query)) {
        ?>
          
            <option value="<?php echo $data['nomorpolisi'];?>" >
            <?php echo $data['nomorpolisi'];?></option>
        <?php
        }
        ?></td>
        </select>
    </td></tr>
    <tr>
        <td> Biaya
        <td> <input type="text" name="biaya"> </td>
    </tr>
    <tr>
        <td> Tujuan
        <td> <input type="text" name="tujuan"> </td>
    </tr>
    <tr>
        <td> Kota Berangkat
        <td> <input type="text" name="kotaberangkat"> </td>
    </tr>
    <tr>
        <td> Tanggal Berangkat
        <td> <input type="date" name="tanggalberangkat"> </td>
    </tr>
    <tr>
        <td> Kota Kembali
        <td> <input type="text" name="kotakembali"> </td>
    </tr>
    <tr>
        <td> Tanggal Kembali
        <td> <input type="date" name="tanggalkembali"> </td>
    </tr>
    <tr>
        <td> Keterangan
        <td> <input type="text" name="keterangan"> </td>
    </tr>
    <tr>
        <td> Lain-lain
        <td> <input type="text" name="lainlain"> </td>
    </tr>
    <tr>
        <td> Petugas
        <td> <input type="text" name="petugas"> </td>
    </tr>

    </tr>
        <td><a class="kembali" href="transaksi.php">Kembali</a></td>
        <td><input type="submit" name="proses" value="Simpan Nota" style= background-color:rgb(25,189,74)> </td>
    </tr>
</form>
</table>
</html>
<?php

if (isset($_POST['proses'])){
    include '../koneksi.php';
  
    $nomor_transaksi = $_POST['nomor_transaksi'];
    $idcustomer = $_POST['idcustomer'];
    $nomorpolisi = $_POST['nomorpolisi'];
    $biaya = $_POST['biaya'];
    $tujuan = $_POST['tujuan'];
    $kotaberangkat = $_POST['kotaberangkat'];
    $tanggalberangkat = $_POST['tanggalberangkat'];
    $kotakembali = $_POST['kotakembali'];
    $tanggalkembali = $_POST['tanggalkembali'];
    $keterangan = $_POST['keterangan'];
    $lainlain = $_POST['lainlain'];
    $petugas = $_POST['petugas'];


    
    
    mysqli_query($conn, "INSERT INTO transaksi VALUES('$nomor_transaksi','$idcustomer','$nomorpolisi','$biaya','$tujuan','$kotaberangkat','$tanggalberangkat','$kotakembali','$tanggalkembali','$keterangan','$lainlain','$petugas')");
    
        // Gunakan nilai $kodenota untuk keperluan selanjutnya
        echo "<script>window.location.href = 'transaksi.php?nomor_transaksi=".$nomor_transaksi."';</script>";

    
}
?>