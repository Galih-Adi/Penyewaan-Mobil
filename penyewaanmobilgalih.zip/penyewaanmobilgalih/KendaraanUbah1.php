<?php
            include 'koneksi.php';
            $query = mysqli_query($conn, "Select*from kendaraan where nomorpolisi = '$_GET[nomorpolisi]'");
            $data = mysqli_fetch_array($query);
            
                ?>
  
<html>
<title>Edit Kendaraan</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f1f1f1;
        margin: 0;
        padding: 20px;
    }

    h3 {
        color: #333;
        font-size: 24px;
        text-align: center;
        margin-bottom: 20px;
    }

    form {
        background-color: #fff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
    }

    table {
        width: 100%;
    }

    h4 {
        text-align: center;
        color: #666;
        font-size: 18px;
        margin-bottom: 10px;
    }

    tr {
        line-height: 2;
    }

    td:first-child {
        text-align: right;
        padding-right: 10px;
        color: #666;
        font-weight: bold;
    }

    input[type="text"] {
        width: 100%;
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 3px;
        font-size: 14px;
    }

    input[type="submit"] {
        padding: 8px 15px;
        background-color: #4CAF50;
        color: #fff;
        border: none;
        border-radius: 3px;
        cursor: pointer;
        font-size: 14px;
    }

    input[type="submit"]:hover {
        background-color: #45a049;
    }

    .kembali {
        
        padding: 10px 10px;
        background-color: #333;
        color: #fff;
        text-decoration: none;
        border-radius: 3px;
        font-size: 14px;
    }

    .kembali:hover {
        background-color: #555;
    }
</style>
<form action="" method="post">
<table>
    <h4>FORM UBAH KENDARAAN</h4>
    <tr>
        <td> Nomor Polisi </td>
        <td> <input type="text" name="nomorpolisi" value="<?php echo $data['nomorpolisi'];?>" readonly> </td>
    </tr>

    <tr>
        <td> Armada </td>
        <td> <input type="text" name="armada" value="<?php echo $data['armada'];?>"> </td>
    </tr>

            <tr>
        <td> Sewa Kendaraan </td>
        <td> <input type="text" name="sewakendaraan" value="<?php echo $data['sewakendaraan'];?>"> </td>
    </tr>
    <tr>
        <td> BBM </td>
        <td> <input type="text" name="bbm" value="<?php echo $data['bbm'];?>"> </td>
    </tr>
    <tr>
        <td> Supir </td>
        <td> <input type="text" name="supir" value="<?php echo $data['supir'];?>"> </td>
    </tr>
    <tr>
        <td> Overtime </td>
        <td> <input type="text" name="overtime" value="<?php echo $data['overtime'];?>"> </td>
    </tr>
    <tr>
        <td> Total </td>
        <td> <input type="text" name="total" value="<?php echo $data['total'];?>"> </td>
    </tr>
    <tr>
        <td></td>
        <td><a class="kembali" href="Kendaraan.php">kembali</a>|<input type="submit" name="proses" value="Ubah Kendaraan">
    </td>
    </tr>
</form>
</table>

</html>

<?php

if (isset($_POST['proses'])){
    include 'koneksi.php';
    $nomorpolisi = $_POST['nomorpolisi'];
    $armada = $_POST['armada'];
    $sewakendaraan = $_POST['sewakendaraan'];
    $bbm = $_POST['bbm'];
    $supir = $_POST['supir'];
    $overtime = $_POST['overtime'];
    $total = $_POST['total'];

    
    
    mysqli_query($conn, "update kendaraan set 
                           armada ='$armada',sewakendaraan='$sewakendaraan', bbm = '$bbm', supir = '$supir', overtime = '$overtime', total = '$total' where nomorpolisi='$nomorpolisi'");
    header("location:Kendaraan.php");
}
?>