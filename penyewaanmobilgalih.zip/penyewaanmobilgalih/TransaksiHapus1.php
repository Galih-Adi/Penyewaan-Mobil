<?php
// include database connection file
include 'koneksi.php';
 
// Get id from URL to delete that user
if (isset($_GET['nomor_transaksi'])) {
    $nomor_transaksi=$_GET['nomor_transaksi'];
}
 
// Delete user row from table based on given id
$result = mysqli_query($conn, "DELETE FROM transaksi WHERE nomor_transaksi ='$nomor_transaksi'");
 
// After delete redirect to Home, so that latest user list will be displayed.
header("Location:Transaksi.php");
?>