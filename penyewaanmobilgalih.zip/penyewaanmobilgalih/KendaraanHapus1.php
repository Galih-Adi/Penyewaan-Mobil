<?php
// include database connection file
include 'koneksi.php';
 
// Get id from URL to delete that user
if (isset($_GET['nomorpolisi'])) {
    $nomorpolisi = $_GET ['nomorpolisi'];
}
 
// Delete user row from table based on given id
$result = mysqli_query($conn, "DELETE FROM Kendaraan WHERE nomorpolisi='$nomorpolisi'");
 
// After delete redirect to Home, so that latest user list will be displayed.
header("Location:Kendaraan.php");
?>